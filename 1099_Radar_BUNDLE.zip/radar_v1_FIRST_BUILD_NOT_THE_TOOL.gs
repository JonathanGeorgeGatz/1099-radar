/* NOT THE TOOL — the FIRST build from prompt 1, kept so you can study the wreck.
   It measures against the retired $600 threshold, counts card/PayPal payments the
   processor already reports, ignores entity and category, and double-counts duplicates.
   Run radar.gs instead. */
/* EP25 first build — "the $600 ghost". REAL wrong build, kept for the episode.
   Bugs (authentic stale-training-data behavior): (1) uses the retired $600 threshold;
   (2) counts card/PayPal/Square payments — the processor's 1099-K job; (3) no entity or
   category logic at all (corporations, goods, rent all land on "needs 1099-NEC");
   (4) no duplicate detection. It does filter the tax year and skip rows it cannot parse (silently). */
var RADAR_V1 = (function () {
  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function cents(s) {
    var t = norm(s).replace(/^\$/, "").replace(/,/g, "");
    if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
    var p = t.split(".");
    return parseInt(p[0], 10) * 100 + (p[1] ? parseInt((p[1] + "0").slice(0, 2), 10) : 0);
  }
  function run(vendorRows, paymentRows) {
    var totals = {};
    for (var r = 1; r < paymentRows.length; r++) {
      var row = paymentRows[r];
      var d = /^(\d{4})-/.exec(norm(row[0]));
      if (!d || +d[1] !== 2026) continue;           // silent skip
      var c = cents(row[5]);
      if (c == null) continue;                       // silent skip
      var v = norm(row[1]);
      if (!v) continue;
      totals[v] = (totals[v] || 0) + c;
    }
    var list = [];
    for (var k in totals) if (totals[k] >= 60000) list.push({ vendor: k, totalCents: totals[k] });
    list.sort(function (a, b) { return b.totalCents - a.totalCents || (a.vendor < b.vendor ? -1 : 1); });
    return { needsNEC: list, headline: { formsNeeded: list.length } };
  }
  return { run: run };
})();
if (typeof module !== "undefined") module.exports = RADAR_V1;
