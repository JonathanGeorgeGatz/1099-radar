/* NOT THE TOOL — the SECOND build from prompt 2, kept so you can study the misses.
   It exempts the law firm (legal services are never exempt), drops Zelle payments as
   if a processor reported them, and subtracts parts & materials from service invoices.
   Run radar.gs instead. */
/* EP25 second build — knows the 2026 law's headline but gets three rules wrong. REAL wrong build.
   Bugs: (1) exempts ALL corporations — including the law firm (legal services are never exempt);
   (2) treats Zelle like PayPal ("an app — the processor reports it"; Zelle is a bank transfer and
   produces no 1099-K); (3) subtracts "Parts & materials" lines from service vendors (the IRS text
   says box 1a includes parts and materials). Otherwise follows the SPEC pipeline. */
var RADAR_V2 = (function () {
  var CORP = { "c corporation": 1, "s corporation": 1, "llc (c corp)": 1, "llc (s corp)": 1 };
  var PROC = { "credit card": 1, "debit card": 1, "paypal": 1, "venmo": 1, "square": 1, "zelle": 1 }; // BUG 2
  var PAYER = { "check": 1, "ach": 1, "cash": 1, "wire": 1 };
  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function fold(s) { return norm(s).toLowerCase(); }
  function cents(s) {
    var t = norm(s).replace(/^\$/, "").replace(/,/g, "");
    if (!/^-?\d+(\.\d{1,2})?$/.test(t)) return null;
    if (t.charAt(0) === "-") return null;
    var p = t.split(".");
    return parseInt(p[0], 10) * 100 + (p[1] ? parseInt((p[1] + "0").slice(0, 2), 10) : 0);
  }
  function days(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(norm(s));
    if (!m) return null;
    var dt = Date.UTC(+m[1], +m[2] - 1, +m[3]);
    var c = new Date(dt);
    if (c.getUTCFullYear() !== +m[1] || c.getUTCMonth() !== +m[2] - 1 || c.getUTCDate() !== +m[3]) return null;
    return { y: +m[1], d: Math.floor(dt / 86400000) };
  }
  function run(vendorRows, paymentRows, settings) {
    var st = settings || {}, threshold = st.threshold != null ? st.threshold : 200000,
        taxYear = st.taxYear != null ? st.taxYear : 2026, dupDays = st.dupDays != null ? st.dupDays : 3;
    var vmap = {};
    for (var i = 1; i < vendorRows.length; i++)
      if (norm(vendorRows[i][0])) vmap[fold(vendorRows[i][0])] = { name: norm(vendorRows[i][0]), entity: fold(vendorRows[i][1]), w9: fold(vendorRows[i][2]) === "yes" };
    var kept = [], refusals = [];
    var acc = {};
    for (var r = 1; r < paymentRows.length; r++) {
      var row = paymentRows[r], v = norm(row[1]), cat = fold(row[3]), method = fold(row[4]);
      var c = cents(row[5]), dt = days(row[0]);
      if (!v || !vmap[fold(v)] || c == null || !dt || (!PROC[method] && !PAYER[method])) { refusals.push(r + 1); continue; }
      if (dt.y !== taxYear) continue;
      var isDup = false;
      if (dupDays > 0) for (var k = 0; k < kept.length; k++) {
        var K = kept[k];
        if (K.v === fold(v) && K.c === c && K.m === method && K.cat === cat && Math.abs(K.d - dt.d) <= dupDays) { isDup = true; break; }
      }
      if (isDup) continue;
      kept.push({ v: fold(v), c: c, m: method, cat: cat, d: dt.d });
      if (PROC[method]) continue;                                  // BUG 2 swallows Zelle here
      if (cat === "goods only") continue;
      var V = vmap[fold(v)];
      if (CORP[V.entity]) continue;                                // BUG 1: no legal-services exception
      if (cat === "rent") acc[V.name] = acc[V.name] || { nec: 0, rent: 0 }, acc[V.name].rent += c;
      else if (cat === "parts & materials") { /* BUG 3: parts dropped */ }
      else acc[V.name] = acc[V.name] || { nec: 0, rent: 0 }, acc[V.name].nec += c;
    }
    var nec = [], misc = [];
    for (var n in acc) {
      if (acc[n].nec >= threshold) nec.push({ vendor: n, totalCents: acc[n].nec });
      if (acc[n].rent >= threshold) misc.push({ vendor: n, totalCents: acc[n].rent });
    }
    function cmp(a, b) { return b.totalCents - a.totalCents || (a.vendor < b.vendor ? -1 : 1); }
    nec.sort(cmp); misc.sort(cmp);
    return { needsNEC: nec, needsMISCRent: misc, headline: { formsNeeded: nec.length + misc.length } };
  }
  return { run: run };
})();
if (typeof module !== "undefined") module.exports = RADAR_V2;
