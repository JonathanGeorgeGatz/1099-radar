#!/usr/bin/env python3
"""EP25 independent checker — implements SPEC.md from scratch (no JS shared). stdin: JSON
{vendors: [[...]], payments: [[...]], settings: {...}} → stdout: canonical report JSON."""
import sys, json
from datetime import date

CORP = {"c corporation", "s corporation", "llc (c corp)", "llc (s corp)"}
PAYER = {"check", "ach", "zelle", "cash", "wire"}
PROC = {"credit card", "debit card", "paypal", "venmo", "square"}
CATS = {"services": "nec", "legal services": "nec", "parts & materials": "nec", "rent": "rent", "goods only": "goods"}
TIERS = {"after-aug-1": 34000, "by-aug-1": 13000, "30-days": 6000}

def norm(s):
    return " ".join(str("" if s is None else s).split())

def fold(s):
    return norm(s).lower()

def parse_cents(s):
    t = norm(s)
    if t.startswith("$"):
        t = t[1:]
    t = t.replace(",", "")
    neg = t.startswith("-")
    if neg:
        t = t[1:]
    if not t or not all(ch.isdigit() or ch == "." for ch in t):
        return None
    parts = t.split(".")
    if len(parts) > 2 or not parts[0] or (len(parts) == 2 and not (1 <= len(parts[1]) <= 2)):
        return None
    if not parts[0].isdigit() or (len(parts) == 2 and not parts[1].isdigit()):
        return None
    cents = int(parts[0]) * 100 + (int((parts[1] + "0")[:2]) if len(parts) == 2 else 0)
    return (cents, neg)

def parse_date(s):
    t = norm(s)
    if len(t) != 10 or t[4] != "-" or t[7] != "-":
        return None
    y, m, d = t[:4], t[5:7], t[8:10]
    if not (y.isdigit() and m.isdigit() and d.isdigit()):
        return None
    try:
        dt = date(int(y), int(m), int(d))
    except ValueError:
        return None
    return (dt.year, dt.toordinal())

def money(c):
    s = f"{c/100:,.2f}"
    return "$" + s

def run(vendors, payments, st):
    threshold = st.get("threshold", 200000)
    tax_year = st.get("taxYear", 2026)
    tier = st.get("penaltyTier", "after-aug-1")
    dup_days = st.get("dupDays", 3)
    per_form = TIERS[tier]

    vmap = {}
    for row in vendors[1:]:
        if norm(row[0]):
            vmap[fold(row[0])] = {"name": norm(row[0]), "entity": fold(row[1]), "w9": fold(row[2]) == "yes"}

    refusals, kept = [], []
    buckets = {k: {"cents": 0, "rows": []} for k in ("card", "corp", "goods", "duplicates", "outOfYear")}
    refused_cents = 0
    data_rows = 0
    acc = {}  # name -> [nec, rent]

    for idx, row in enumerate(payments[1:], start=2):
        data_rows += 1
        vname, cat, method = norm(row[1]), fold(row[3]), fold(row[4])
        amt = parse_cents(row[5])
        dt = parse_date(row[0])
        reason = None
        if not vname:
            reason = "blank vendor"
        elif fold(vname) not in vmap:
            reason = "vendor not in the Vendors tab"
        elif amt is None:
            reason = "bad amount"
        elif amt[1]:
            reason = "negative amount — handle refunds by hand"
        elif dt is None:
            reason = "bad date"
        elif cat not in CATS:
            reason = "unknown category"
        elif method not in PAYER and method not in PROC:
            reason = "unknown method"
        if reason:
            refusals.append({"row": idx, "vendor": vname, "reason": reason})
            if amt is not None and not amt[1]:
                refused_cents += amt[0]
            continue
        cents = amt[0]
        if dt[0] != tax_year:
            buckets["outOfYear"]["cents"] += cents
            buckets["outOfYear"]["rows"].append(idx)
            continue
        dup = False
        if dup_days > 0:
            for K in kept:
                if K[0] == fold(vname) and K[1] == cents and K[2] == method and K[3] == cat and abs(K[4] - dt[1]) <= dup_days:
                    dup = True
                    break
        if dup:
            buckets["duplicates"]["cents"] += cents
            buckets["duplicates"]["rows"].append(idx)
            continue
        kept.append((fold(vname), cents, method, cat, dt[1]))
        V = vmap[fold(vname)]
        if method in PROC:
            buckets["card"]["cents"] += cents
            buckets["card"]["rows"].append(idx)
            continue
        if CATS[cat] == "goods":
            buckets["goods"]["cents"] += cents
            buckets["goods"]["rows"].append(idx)
            continue
        if V["entity"] in CORP and cat != "legal services":
            buckets["corp"]["cents"] += cents
            buckets["corp"]["rows"].append(idx)
            continue
        a = acc.setdefault(V["name"], [0, 0])
        if CATS[cat] == "rent":
            a[1] += cents
        else:
            a[0] += cents

    needs_nec, needs_misc, under_v, chase = [], [], [], {}
    counted_nec = counted_rent = under_cents = 0
    for key, V in vmap.items():
        nec, rent = acc.get(V["name"], [0, 0])
        if nec >= threshold:
            note = "services"
            if V["entity"] in ("c corporation", "s corporation"):
                note += " — legal services: the corporation exemption does not apply"
            needs_nec.append({"vendor": V["name"], "totalCents": nec,
                              "w9": "READY" if V["w9"] else "GET W-9 FIRST", "note": note})
            counted_nec += nec
            if not V["w9"]:
                chase[V["name"]] = chase.get(V["name"], 0) + 1
        elif nec > 0:
            under_cents += nec
            under_v.append({"vendor": V["name"], "totalCents": nec})
        if rent >= threshold:
            needs_misc.append({"vendor": V["name"], "totalCents": rent,
                               "w9": "READY" if V["w9"] else "GET W-9 FIRST", "note": "rent (box 1)"})
            counted_rent += rent
            if not V["w9"]:
                chase[V["name"]] = chase.get(V["name"], 0) + 1
        elif rent > 0:
            under_cents += rent
            under_v.append({"vendor": V["name"], "totalCents": rent})

    key_fn = lambda e: (-e["totalCents"], e["vendor"])
    needs_nec.sort(key=key_fn)
    needs_misc.sort(key=key_fn)
    under_v.sort(key=key_fn)

    w9_chase, missing = [], 0
    for n in sorted(chase):
        missing += chase[n]
        w9_chase.append({"vendor": n, "formCount": chase[n],
                         "note": "backup withholding (24%) applies to future payments until the W-9 lands"})
    both = per_form * 2
    penalty = {"missingForms": missing, "perFormCents": per_form, "bothCopiesCents": both,
               "exposureCents": missing * both,
               "line": f"IRS penalty per form, returns due 2027: {money(per_form)} — charged once for the IRS copy and again for the payee copy"}

    resum = 0
    for row in payments[1:]:
        a = parse_cents(row[5])
        if a is not None and not a[1]:
            resum += a[0]
    parts_sum = (counted_nec + counted_rent + buckets["card"]["cents"] + buckets["corp"]["cents"] +
                 buckets["goods"]["cents"] + under_cents + buckets["duplicates"]["cents"] +
                 buckets["outOfYear"]["cents"] + refused_cents)
    tie = resum == parts_sum
    trust = "OK" if (tie and (data_rows == 0 or len(refusals) / data_rows <= 0.05)) else "DO NOT TRUST THIS REPORT"

    out_buckets = dict(buckets)
    out_buckets["underThreshold"] = {"cents": under_cents, "vendors": under_v}
    return {
        "needsNEC": needs_nec, "needsMISCRent": needs_misc, "w9Chase": w9_chase, "penalty": penalty,
        "buckets": out_buckets, "refusals": refusals,
        "recon": {"parseableCents": resum, "countedNecCents": counted_nec, "countedRentCents": counted_rent,
                  "cardCents": buckets["card"]["cents"], "corpCents": buckets["corp"]["cents"],
                  "goodsCents": buckets["goods"]["cents"], "underCents": under_cents,
                  "dupCents": buckets["duplicates"]["cents"], "outOfYearCents": buckets["outOfYear"]["cents"],
                  "refusedCents": refused_cents, "tie": tie},
        "trust": trust,
        "headline": {"formsNeeded": len(needs_nec) + len(needs_misc), "necCount": len(needs_nec),
                     "miscCount": len(needs_misc), "chaseCount": len(w9_chase)},
    }

if __name__ == "__main__":
    j = json.load(sys.stdin)
    print(json.dumps(run(j["vendors"], j["payments"], j.get("settings", {})), sort_keys=True))
