# EP25 — The 1099 Radar — SPEC (written BEFORE any implementation; both implementations follow THIS)

A Google Sheets + Apps Script tool. Three input tabs → one Report. Pure core `runRadar(vendorRows, paymentRows, settings)`.
It prepares; it files nothing and sends nothing. Not tax advice; it applies the IRS's own published thresholds.

## Inputs
**Vendors tab** header: `Vendor, Entity type, W-9 on file, Email`
- Entity type (case-insensitive, trimmed): one of `individual`, `sole proprietor`, `partnership`,
  `llc (partnership)`, `llc (c corp)`, `llc (s corp)`, `c corporation`, `s corporation`, or blank.
- "corporation" class = `c corporation`, `s corporation`, `llc (c corp)`, `llc (s corp)`.
- W-9 on file: `yes` → true; anything else (incl. blank, `no`) → false.
- Blank entity ⇒ UNKNOWN ⇒ treated as reportable (you cannot prove the exemption without the W-9).

**Payments tab** header: `Date, Vendor, Description, Category, Method, Amount`
- Date: `YYYY-MM-DD` only. Anything else ⇒ refusal `bad date`.
- Amount: optional `$`, thousands commas allowed, 2 decimals or none; parsed to INTEGER CENTS.
  Unparseable ⇒ refusal `bad amount`. Negative ⇒ refusal `negative amount — handle refunds by hand`.
- Category (case-insensitive): `services`, `legal services`, `parts & materials`, `rent`, `goods only`.
  Anything else ⇒ refusal `unknown category`.
- Method (case-insensitive): payer-reportable = `check`, `ach`, `zelle`, `cash`, `wire`;
  processor-reported = `credit card`, `debit card`, `paypal`, `venmo`, `square`.
  Anything else ⇒ refusal `unknown method`.
- Vendor not present in Vendors tab ⇒ refusal `vendor not in the Vendors tab`. Blank vendor ⇒ refusal `blank vendor`.

## Settings (defaults)
- `threshold` = 200000 cents ($2,000 — the TY2026 law; set 60000 to see the retired $600 rule)
- `taxYear` = 2026 (only payments dated in this calendar year count; others → OUT OF YEAR bucket)
- `penaltyTier` = `after-aug-1` (per-form $340) | `by-aug-1` ($130) | `30-days` ($60)  [IRS table, returns due 2027]
- `dupDays` = 3 (exact duplicate detection window; 0 disables)

## Row pipeline (order is law; each parseable in-year dollar lands in EXACTLY ONE bucket)
1. Parse/refuse (reasons above, exact strings; refusal lists row number of the sheet, 2-based incl. header).
2. Out-of-year: date.year ≠ taxYear ⇒ bucket `outOfYear`.
3. Duplicate: a row whose (vendor, amount, method, category) matches an EARLIER kept row dated within
   `dupDays` days (inclusive) ⇒ bucket `duplicates` (flagged, not counted). dupDays=0 ⇒ never.
4. Method: processor-reported method ⇒ bucket `card` ("the processor reports these on Form 1099-K — not yours to file").
5. Category `goods only` ⇒ bucket `goods`.
6. Entity: corporation class AND category ≠ `legal services` ⇒ bucket `corp`.
   (Legal services are NEVER exempt: "The exemption from reporting payments made to corporations does not apply to payments for legal services." — IRS i1099mec 12/2026.)
7. Remaining rows accumulate per vendor: category `rent` → rentCents; `services`/`legal services`/`parts & materials` → necCents.
   ("including parts and materials" — IRS i1099mec, NEC box 1a.)

## Vendor verdicts (after accumulation)
- necCents ≥ threshold ⇒ **NEEDS 1099-NEC**.
- rentCents ≥ threshold ⇒ **NEEDS 1099-MISC (rent, box 1)**.
- A vendor can need both. Vendor dollars below threshold ⇒ bucket `underThreshold` (per bucket type).
- W-9 status per needed form: w9 on file ⇒ `READY`; else ⇒ `GET W-9 FIRST`.

## Output object (exact strings; all money as integer cents; lists sorted by total desc, then vendor A→Z)
```
{
  needsNEC:   [{vendor, totalCents, w9: "READY"|"GET W-9 FIRST", note}],
  needsMISCRent: [{vendor, totalCents, w9, note}],
  w9Chase:    [{vendor, formCount, note: "backup withholding (24%) applies to future payments until the W-9 lands"}],
  penalty:    {missingForms, perFormCents, bothCopiesCents, exposureCents,
               line: "IRS penalty per form, returns due 2027: $<per> — charged once for the IRS copy and again for the payee copy"},
  buckets:    {card, corp, goods, underThreshold, duplicates, outOfYear}  // each {cents, rows:[...] or vendors:[...]}
  refusals:   [{row, vendor, reason}],
  recon:      {parseableCents, countedNecCents, countedRentCents, cardCents, corpCents, goodsCents,
               underCents, dupCents, outOfYearCents, refusedCents, tie: true|false},
  trust:      "OK" | "DO NOT TRUST THIS REPORT",
  headline:   {formsNeeded, necCount, miscCount, chaseCount}
}
```
- penalty.perFormCents by tier: after-aug-1 34000 · by-aug-1 13000 · 30-days 6000. bothCopies = ×2.
  exposure = missingForms × bothCopies. missingForms = number of NEEDED forms whose vendor lacks a W-9.
- recon.tie: parseableCents === counted(NEC)+counted(rent)+card+corp+goods+under+dup+outOfYear+refusedParseable.
  (refusedCents sums only refusal rows whose amount parses; bad-amount rows carry no cents.)
- trust = DO NOT TRUST when recon.tie is false OR refusals > 5% of data rows.

## Refusal precedence (a row failing several checks reports the FIRST reason in this order)
1. `blank vendor` · 2. `vendor not in the Vendors tab` · 3. `bad amount` · 4. `negative amount — handle refunds by hand` · 5. `bad date` · 6. `unknown category` · 7. `unknown method`

Duplicate detection compares against earlier NON-REFUSED, IN-YEAR rows (any bucket), key = (vendor, amount, method, category), window inclusive.

## Tie-breaks & determinism
- Duplicate matching scans rows in sheet order; the EARLIER row is kept.
- Date comparison by UTC calendar days. Vendor name matching: exact after trim + case-fold.
- No floating point anywhere in money; cents only. No network calls of any kind (no UrlFetchApp).
