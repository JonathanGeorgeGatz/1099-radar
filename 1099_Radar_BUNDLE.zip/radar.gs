/* ============================================================================
   THE 1099 RADAR — Build It With AI, Episode 25 (free giveaway)
   Google Sheets + Apps Script. It prepares; it files NOTHING and sends NOTHING.

   Tabs it reads:
     Vendors  : Vendor | Entity type | W-9 on file | Email
     Payments : Date (YYYY-MM-DD) | Vendor | Description | Category | Method | Amount
     Settings : optional — threshold (dollars), taxYear, penaltyTier, dupDays

   What it applies (sources in README.txt; read them, then talk to your bookkeeper):
   · TY2026 reporting threshold $2,000 (was $600) — IRS Instructions for Forms
     1099-MISC and 1099-NEC (12/2026), "tax years beginning after 2025".
   · Corporations exempt — EXCEPT legal services. · Card / PayPal / app-network
     payments are the processor's 1099-K job, not yours. Zelle is a bank transfer:
     still yours. · Rent ≥ threshold → 1099-MISC box 1. · Missing W-9 → backup
     withholding (24%) + you cannot file. · Penalty table: returns due 2027.
   NOT TAX ADVICE. It organizes your own ledger so the conversation with your
   accountant takes minutes instead of a weekend.
   ============================================================================ */

/* EP25 — The 1099 Radar — shipped engine core (pure; no I/O, no network). Follows SPEC.md exactly. */
var RADAR = (function () {
  var CORP = { "c corporation": 1, "s corporation": 1, "llc (c corp)": 1, "llc (s corp)": 1 };
  var PAYER_METHODS = { "check": 1, "ach": 1, "zelle": 1, "cash": 1, "wire": 1 };
  var PROC_METHODS = { "credit card": 1, "debit card": 1, "paypal": 1, "venmo": 1, "square": 1 };
  var CATS = { "services": "nec", "legal services": "nec", "parts & materials": "nec", "rent": "rent", "goods only": "goods" };
  var TIERS = { "after-aug-1": 34000, "by-aug-1": 13000, "30-days": 6000 };

  function norm(s) { return String(s == null ? "" : s).replace(/\s+/g, " ").trim(); }
  function fold(s) { return norm(s).toLowerCase(); }
  function parseDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(norm(s));
    if (!m) return null;
    var y = +m[1], mo = +m[2], d = +m[3];
    if (mo < 1 || mo > 12 || d < 1 || d > 31) return null;
    var dt = Date.UTC(y, mo - 1, d);
    var c = new Date(dt);
    if (c.getUTCFullYear() !== y || c.getUTCMonth() !== mo - 1 || c.getUTCDate() !== d) return null;
    return { y: y, days: Math.floor(dt / 86400000) };
  }
  function parseCents(s) {
    var t = norm(s).replace(/^\$/, "").replace(/,/g, "");
    if (!/^-?\d+(\.\d{1,2})?$/.test(t)) return null;
    var neg = t.charAt(0) === "-";
    if (neg) t = t.slice(1);
    var parts = t.split(".");
    var cents = parseInt(parts[0], 10) * 100 + (parts[1] ? parseInt((parts[1] + "0").slice(0, 2), 10) : 0);
    return { cents: cents, neg: neg };
  }
  function money(c) {
    var s = (c / 100).toFixed(2);
    return "$" + s.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  function run(vendorRows, paymentRows, settings) {
    var st = settings || {};
    var threshold = st.threshold != null ? st.threshold : 200000;
    var taxYear = st.taxYear != null ? st.taxYear : 2026;
    var tier = st.penaltyTier || "after-aug-1";
    var dupDays = st.dupDays != null ? st.dupDays : 3;
    var perForm = TIERS[tier];

    var vmap = {};
    for (var i = 1; i < vendorRows.length; i++) {
      var vr = vendorRows[i];
      if (!norm(vr[0])) continue;
      vmap[fold(vr[0])] = { name: norm(vr[0]), entity: fold(vr[1]), w9: fold(vr[2]) === "yes" };
    }

    var refusals = [], kept = [], dataRows = 0;
    var buckets = { card: { cents: 0, rows: [] }, corp: { cents: 0, rows: [] }, goods: { cents: 0, rows: [] },
                    underThreshold: { cents: 0, vendors: [] }, duplicates: { cents: 0, rows: [] },
                    outOfYear: { cents: 0, rows: [] } };
    var refusedCents = 0;

    for (var r = 1; r < paymentRows.length; r++) {
      var row = paymentRows[r];
      dataRows++;
      var sheetRow = r + 1; // 1-based + header
      var vname = norm(row[1]), cat = fold(row[3]), method = fold(row[4]);
      var amt = parseCents(row[5]);
      var refuse = null;
      if (!vname) refuse = "blank vendor";
      else if (!vmap[fold(vname)]) refuse = "vendor not in the Vendors tab";
      if (!refuse && amt == null) refuse = "bad amount";
      if (!refuse && amt && amt.neg) refuse = "negative amount — handle refunds by hand";
      var dt = parseDate(row[0]);
      if (!refuse && !dt) refuse = "bad date";
      if (!refuse && !(cat in CATS)) refuse = "unknown category";
      if (!refuse && !PAYER_METHODS[method] && !PROC_METHODS[method]) refuse = "unknown method";
      if (refuse) {
        refusals.push({ row: sheetRow, vendor: vname, reason: refuse });
        if (amt && !amt.neg) refusedCents += amt.cents;
        continue;
      }
      var cents = amt.cents;
      if (dt.y !== taxYear) { buckets.outOfYear.cents += cents; buckets.outOfYear.rows.push(sheetRow); continue; }
      // duplicate check against earlier KEPT rows
      var isDup = false;
      if (dupDays > 0) {
        for (var k = 0; k < kept.length; k++) {
          var K = kept[k];
          if (K.vkey === fold(vname) && K.cents === cents && K.method === method && K.cat === cat &&
              Math.abs(K.days - dt.days) <= dupDays) { isDup = true; break; }
        }
      }
      if (isDup) { buckets.duplicates.cents += cents; buckets.duplicates.rows.push(sheetRow); continue; }
      kept.push({ vkey: fold(vname), cents: cents, method: method, cat: cat, days: dt.days, sheetRow: sheetRow });
      var V = vmap[fold(vname)];
      if (PROC_METHODS[method]) { buckets.card.cents += cents; buckets.card.rows.push(sheetRow); V.hadCard = true; continue; }
      if (CATS[cat] === "goods") { buckets.goods.cents += cents; buckets.goods.rows.push(sheetRow); continue; }
      if (CORP[V.entity] && cat !== "legal services") { buckets.corp.cents += cents; buckets.corp.rows.push(sheetRow); continue; }
      if (CATS[cat] === "rent") V.rentCents = (V.rentCents || 0) + cents;
      else V.necCents = (V.necCents || 0) + cents;
    }

    var needsNEC = [], needsMISC = [], chase = {}, countedNec = 0, countedRent = 0, underCents = 0, underV = [];
    for (var key in vmap) {
      var V2 = vmap[key];
      var nec = V2.necCents || 0, rent = V2.rentCents || 0;
      if (nec >= threshold) {
        needsNEC.push({ vendor: V2.name, totalCents: nec, w9: V2.w9 ? "READY" : "GET W-9 FIRST",
                        note: "services" + (V2.entity === "c corporation" || V2.entity === "s corporation" ? " — legal services: the corporation exemption does not apply" : "") });
        countedNec += nec;
        if (!V2.w9) chase[V2.name] = (chase[V2.name] || 0) + 1;
      } else if (nec > 0) { underCents += nec; underV.push({ vendor: V2.name, totalCents: nec }); }
      if (rent >= threshold) {
        needsMISC.push({ vendor: V2.name, totalCents: rent, w9: V2.w9 ? "READY" : "GET W-9 FIRST", note: "rent (box 1)" });
        countedRent += rent;
        if (!V2.w9) chase[V2.name] = (chase[V2.name] || 0) + 1;
      } else if (rent > 0) { underCents += rent; underV.push({ vendor: V2.name, totalCents: rent }); }
    }
    function cmp(a, b) { return b.totalCents - a.totalCents || (a.vendor < b.vendor ? -1 : a.vendor > b.vendor ? 1 : 0); }
    needsNEC.sort(cmp); needsMISC.sort(cmp); underV.sort(cmp);
    buckets.underThreshold.cents = underCents; buckets.underThreshold.vendors = underV;

    var w9Chase = [], missingForms = 0;
    Object.keys(chase).sort().forEach(function (n) {
      missingForms += chase[n];
      w9Chase.push({ vendor: n, formCount: chase[n],
                     note: "backup withholding (24%) applies to future payments until the W-9 lands" });
    });
    var bothCopies = perForm * 2;
    var penalty = { missingForms: missingForms, perFormCents: perForm, bothCopiesCents: bothCopies,
                    exposureCents: missingForms * bothCopies,
                    line: "IRS penalty per form, returns due 2027: " + money(perForm) +
                          " — charged once for the IRS copy and again for the payee copy" };

    var parseable = countedNec + countedRent + buckets.card.cents + buckets.corp.cents + buckets.goods.cents +
                    underCents + buckets.duplicates.cents + buckets.outOfYear.cents + refusedCents;
    // independent re-sum for the tie
    var resum = 0;
    for (var r2 = 1; r2 < paymentRows.length; r2++) {
      var a2 = parseCents(paymentRows[r2][5]);
      if (a2 && !a2.neg) resum += a2.cents;
    }
    var tie = resum === parseable;
    var refShare = dataRows ? refusals.length / dataRows : 0;
    var trust = (tie && refShare <= 0.05) ? "OK" : "DO NOT TRUST THIS REPORT";

    return {
      needsNEC: needsNEC, needsMISCRent: needsMISC, w9Chase: w9Chase, penalty: penalty, buckets: buckets,
      refusals: refusals,
      recon: { parseableCents: resum, countedNecCents: countedNec, countedRentCents: countedRent,
               cardCents: buckets.card.cents, corpCents: buckets.corp.cents, goodsCents: buckets.goods.cents,
               underCents: underCents, dupCents: buckets.duplicates.cents, outOfYearCents: buckets.outOfYear.cents,
               refusedCents: refusedCents, tie: tie },
      trust: trust,
      headline: { formsNeeded: needsNEC.length + needsMISC.length, necCount: needsNEC.length,
                  miscCount: needsMISC.length, chaseCount: w9Chase.length }
    };
  }
  return { run: run, money: money, parseCents: parseCents };
})();
if (typeof module !== "undefined") module.exports = RADAR;


/* ---------- Apps Script wrapper ---------- */
var __lastResult;

function onOpen() {
  SpreadsheetApp.getUi().createMenu("1099 Radar").addItem("Build the report", "buildReport").addToUi();
}

function readSettings(ss) {
  var st = { threshold: 200000, taxYear: 2026, penaltyTier: "after-aug-1", dupDays: 3 };
  var sh = ss.getSheetByName("Settings");
  if (!sh) return st;
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    var k = String(rows[i][0] || "").trim(), v = String(rows[i][1] || "").trim();
    if (k === "threshold" && /^\d+(\.\d{1,2})?$/.test(v)) st.threshold = Math.round(parseFloat(v) * 100);
    if (k === "taxYear" && /^\d{4}$/.test(v)) st.taxYear = parseInt(v, 10);
    if (k === "penaltyTier" && (v === "after-aug-1" || v === "by-aug-1" || v === "30-days")) st.penaltyTier = v;
    if (k === "dupDays" && /^\d+$/.test(v)) st.dupDays = parseInt(v, 10);
  }
  return st;
}

function buildReport() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var vSheet = ss.getSheetByName("Vendors"), pSheet = ss.getSheetByName("Payments");
  if (!vSheet) throw new Error("No 'Vendors' tab. The Radar refuses to guess who your vendors are.");
  if (!pSheet) throw new Error("No 'Payments' tab. Paste your ledger there first.");
  var st = readSettings(ss);
  var R = RADAR.run(vSheet.getDataRange().getValues(), pSheet.getDataRange().getValues(), st);
  __lastResult = R;

  var out = [];
  var M = RADAR.money;
  out.push(["THE 1099 RADAR — tax year " + st.taxYear + " (threshold " + M(st.threshold) + ")", "", "", ""]);
  out.push(["Trust check", R.trust, "", ""]);
  out.push(["", "", "", ""]);
  out.push(["FORMS TO FILE: " + R.headline.formsNeeded + "  (" + R.headline.necCount + " × 1099-NEC, " + R.headline.miscCount + " × 1099-MISC rent)", "", "", ""]);
  out.push(["Form", "Vendor", "2026 total", "W-9"]);
  R.needsNEC.forEach(function (e) { out.push(["1099-NEC", e.vendor, M(e.totalCents), e.w9 + (e.note.indexOf("legal") >= 0 ? " — " + e.note : "")]); });
  R.needsMISCRent.forEach(function (e) { out.push(["1099-MISC (rent)", e.vendor, M(e.totalCents), e.w9]); });
  out.push(["", "", "", ""]);
  out.push(["W-9s TO CHASE: " + R.headline.chaseCount, "", "", ""]);
  R.w9Chase.forEach(function (e) { out.push(["", e.vendor, e.formCount + " form(s)", e.note]); });
  out.push([R.penalty.line, "", "", ""]);
  out.push(["Exposure if those forms never get filed: " + M(R.penalty.exposureCents) + "  (" + R.penalty.missingForms + " × " + M(R.penalty.bothCopiesCents) + ")", "", "", ""]);
  out.push(["", "", "", ""]);
  out.push(["NOT YOURS / NOT NEEDED", "", "", ""]);
  out.push(["Card & app-network payments — the processor reports these on Form 1099-K", M(R.buckets.card.cents), "rows " + R.buckets.card.rows.join(", "), ""]);
  out.push(["Corporations (non-legal)", M(R.buckets.corp.cents), "rows " + R.buckets.corp.rows.join(", "), ""]);
  out.push(["Goods only", M(R.buckets.goods.cents), "rows " + R.buckets.goods.rows.join(", "), ""]);
  out.push(["Under the " + M(st.threshold) + " threshold", M(R.buckets.underThreshold.cents),
            R.buckets.underThreshold.vendors.map(function (v) { return v.vendor + " " + M(v.totalCents); }).join(" · "), ""]);
  out.push(["Exact duplicates (counted once)", M(R.buckets.duplicates.cents), "rows " + R.buckets.duplicates.rows.join(", "), ""]);
  out.push(["Out of tax year", M(R.buckets.outOfYear.cents), "rows " + R.buckets.outOfYear.rows.join(", "), ""]);
  out.push(["", "", "", ""]);
  out.push(["REFUSED ROWS: " + R.refusals.length, "", "", ""]);
  R.refusals.forEach(function (e) { out.push(["row " + e.row, e.vendor, e.reason, ""]); });
  out.push(["", "", "", ""]);
  var rc = R.recon;
  out.push(["SELF-AUDIT", rc.tie ? "ties to the cent" : "DOES NOT TIE", "", ""]);
  out.push(["Ledger (parseable)", M(rc.parseableCents), "= NEC " + M(rc.countedNecCents) + " + rent " + M(rc.countedRentCents) +
            " + card " + M(rc.cardCents) + " + corp " + M(rc.corpCents) + " + goods " + M(rc.goodsCents) +
            " + under " + M(rc.underCents) + " + dup " + M(rc.dupCents) + " + out-of-year " + M(rc.outOfYearCents) +
            " + refused " + M(rc.refusedCents), ""]);

  var rep = ss.getSheetByName("1099 Radar Report") || ss.insertSheet("1099 Radar Report");
  rep.clearContents();
  rep.getRange(1, 1, out.length, 4).setValues(out.map(function (r) { return [r[0], r[1], r[2], r[3]]; }));
  return R;
}
